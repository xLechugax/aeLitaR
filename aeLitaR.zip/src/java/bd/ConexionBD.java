package bd;
import java.sql.*;

public class ConexionBD 
{
    private static String url = "jdbc:mysql://50.31.134.63:3306/soller99_aelita";
    private static String user= "soller99_aelita";
    private static String pass= "soller99_aelita";
    private static Connection conn = null;
    
    public static Connection getConexion()
    {
        try
        {
            if(conn==null)
            {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection(url,user,pass);
            }

            return conn;
        }
        catch(Exception e)
        {
            System.err.println("Excepción de Conexión de SQL: " + e);
            return null;
        }
    }
}
